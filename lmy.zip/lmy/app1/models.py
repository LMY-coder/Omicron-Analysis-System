from django.db import models

# Create your models here.
class UserInfo(models.Model):
    name=models.CharField(max_length=64)
    pwd=models.CharField(max_length=64)

    '''
    orm读到这里时会自动创建table，表名为app名+下划线+类的名称小写，即app1_userinfo
    create table app1_userinfo(
    id bigint auto_increment primary key,
    name varchar(64),
    password varchar(64)
    )
    '''