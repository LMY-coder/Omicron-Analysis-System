from django.shortcuts import render, HttpResponse
# Create your views here.
def index(requests):
    return HttpResponse("welcome to lmy web")

def user(requests):
    #默认状况下
    return render(requests, "a.html")

#用户登录
def login(requests):
    if requests.method=="GET":
        return render(requests, "log.html")
    else:
        #如果是POST请求，则获取用户提交的数据
        #jango比flask多了一层csrf_token的验证
        username = requests.POST.get('username')
        password = requests.POST.get('password')
        print("check successfully")
        if username == '13723068753' and password == '123456':
            return render(requests, 'home.html')

def check_login(requests):
    username=requests.POST.get('username')
    password=requests.POST.get('password')
    print("check successfully")
    if username=='13723068753' and password =='123456':
        return render(requests, 'home.html')

def home(requests):
    return render(requests, "home.html")

def page(requests):
    return render(requests, "page.html")

def tdjs(requests):
    return render(requests, "tdjs.html")

def xtjj(requests):
    return render(requests, "xtjs.html")

def fycs(requests):
    return render(requests, "fycs.html")

def policy(requests):
    return render(requests, "policy.html")

def query(requests):
    return render(requests, "query.html")

def news(requests):
    return render(requests, "news.html")

def vaccine(requests):
    return render(requests, "vaccine.html")

def variant(requests):
    return render(requests, "variants.html")

def omicron(requests):
    return render(requests, "omicron.html")

def early(requests):
    return render(requests, "early.html")

def globall(requests):
    return render(requests, "global.html")

def md(requests):
    return render(requests, "model.html")

def overall(requests):
    return render(requests, "overall.html")

def twitter(requests):
    return render(requests, "twitter.html")

def machine(requests):
    return render(requests, "machine.html")

def blog(requests):
    return render(requests, "blog.html")