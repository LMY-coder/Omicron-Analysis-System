// 下拉
var pub_url = "http://120.55.241.242:8090"
// var pub_url = "http://localhost:8090"
var mounth_map = "06"; //地图默认月份

var mounth_tomorrow; //明天所在的月份
var day_tomorrow; //明天的日子
var mounth_map_en = "Jun" //曲线左侧月份 英文
var mounth_map_day = "14"; //全球>日
var date = "2020-03-13"; //全球年月日预测
var qxl_year = "2020" //左侧曲线默认年份
var qx_country = "Global"; //曲线部分默认国家
var have_length = 0; //右侧曲线部分数据长度，用于默认数据展示
//获取当前年份
var day3 = new Date();
day3.setTime(day3.getTime());
var yearNow = day3.getFullYear();

var day4 = new Date();
day4.setTime(day4.getTime() + 24 * 60 * 60 * 1000);
// day4.setTime(day4.getTime() - 24 * 60 * 60 * 1000 * 4);
var map_mounth = day4.getFullYear();
day_tomorrow = day4.getDate();
console.log(day4)
console.log(day_tomorrow)
console.log(map_mounth)


var year_map = map_mounth //地图默认年份
console.log(yearNow)
// 判断当前月份
var myDate = new Date();
qxl_year = myDate.getFullYear();
//获取当前月
var month_current = myDate.getMonth() + 1;
var mounth_line = month_current; //折线图月份
if (mounth_line < 10) {
	mounth_line = "0" + mounth_line
}
var countryL = "Global" //左侧折线国家
var countryR = "Global"; //国家和地区
var curver_date = mounth_line - 1; //曲线右侧时间
if (curver_date < 10) {
	curver_date = "0" + curver_date;
}
// 处理地图明天的日期
var myDate = new Date();
myDate.setTime(myDate.getTime() + 24 * 60 * 60 * 1000);
// myDate.setTime(myDate.getTime() - 24 * 60 * 60 * 1000 * 4);
var s3 = myDate.getFullYear() + "-" + (myDate.getMonth() + 1) + "-" + myDate.getDate();
mounth_tomorrow = myDate.getMonth() + 1;
mounth_map = mounth_tomorrow;
$(function() {
	// 页面加载完成后加载echat

	var drag = function(obj) {

		obj.bind("mousedown", start);

		function start(event) {
			if (event.button == 0) { //判断是否点击鼠标左键
				gapX = event.clientX;
				startx = $(".worldSwitch .dateL ul").css("marginLeft"); // scroll的初始位置
				//movemove事件必须绑定到$(document)上，鼠标移动是在整个屏幕上的
				$(document).bind("mousemove", move);
				//此处的$(document)可以改为obj
				$(document).bind("mouseup", stop);
			}
			return false; //阻止默认事件或冒泡
		}

		function move(event) {
			var left = event.clientX - gapX; // 鼠标移动的相对距离
			var startLeft = parseInt($(".worldSwitch .dateR ul").css("marginLeft"));
			var marginNum = startLeft + left;
			if (marginNum > 0) {
				marginNum = 0;
			} else if (marginNum < -350) {
				marginNum = -350;
			}

			$(".worldSwitch .dateR ul").css("margin-left", marginNum + "px");


			return false; //阻止默认事件或冒泡
		}

		function stop() {
			//解绑定，这一步很必要，前面有解释
			$(document).unbind("mousemove", move);
			$(document).unbind("mouseup", stop);
		}
	}
	obj = $(".worldSwitch .dateR ul");
	drag(obj); //传入的必须是jQuery对象，否则不能调用jQuery的自定义函数

	// 点击时间轴滚动
	$(".worldSwitch .right_slide").click(function() {
		var leftNum = -70;
		var startLeft = parseInt($(".worldSwitch .dateR ul").css("marginLeft"));
		if (startLeft <= -350) {
			leftNum = 0;
		}
		leftNum += startLeft;
		$(".worldSwitch .dateR ul").animate({
			marginLeft: leftNum
		})
	})
	// 全球月份
	$(".worldSwitch .dateL").hover(function() {
		$(".worldSwitch .dateL ul").stop().slideUp();
		$(this).find("ul").stop().slideDown();
	}, function() {
		$(this).find("ul").stop().slideUp();
	})
	// 折线月份
	$(".mounthBox").hover(function() {
		$(".mounthBox .mounth-cont").stop().slideUp();
		$(this).parent().find(".mounth-cont").stop().slideDown();
	}, function() {
		$(this).parent().find(".mounth-cont").stop().slideUp();
	})
})
// 全球月份预测
$(".worldSwitch .dateL ul").on("click", ".allow", function() {
	$(".worldSwitch .dateL ul li").removeClass("active");
	$(this).addClass("active"); // 添加索引类名
	var ch_text = $(this).find("p").text().trim(); //获取月份文本
	var en_text = $(this).find("span").text().trim(); //获取月份英文
	var mm_text = en_text.substring(0, en_text.length - 5); //截取英文月份
	var yy_text = en_text.substring(en_text.length - 4)
	var mounth_en = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"]
	year_map = yy_text;
	// 替换文本
	$(".worldSwitch .dateL>p").text(ch_text);
	$(".worldSwitch .dateL>span").text(en_text)
	$(".worldSwitch #global>h2").text("全球猴痘累计新增病例分布情况预测");
	var index = $(this).index() + 1;
	if (mm_text == "Jan") {
		mounth_map = "01";
	} else if (mm_text == "Feb") {
		mounth_map = "02";
	} else if (mm_text == "Mar") {
		mounth_map = "03";
	} else if (mm_text == "Apr") {
		mounth_map = "04";
	} else if (mm_text == "May") {
		mounth_map = "05";
	} else if (mm_text == "Jun") {
		mounth_map = "06";
	} else if (mm_text == "Jul") {
		mounth_map = "07";
	} else if (mm_text == "Aug") {
		mounth_map = "08";
	} else if (mm_text == "Sept") {
		mounth_map = "09";
	} else if (mm_text == "Oct") {
		mounth_map = "10";
	} else if (mm_text == "Nov") {
		mounth_map = "11";
	} else if (mm_text == "Dec") {
		mounth_map = "12";
	}

	$(".worldSwitch #global>p").text(mounth_en[mounth_map]);
	mounth_map_en = mm_text; //英文月份
	// 判断每月的天数
	// console.log(day_tomorrow)
	// console.log(mounth_map)
	// console.log(yy_text)
	$.ajax({
		type: "post",
		async: false,
		url: pub_url + "/predictData/monkeypoxEchartsData/globalData",
		data: {
			timeMonth: mounth_map,
			timeYear: yy_text,
			timeDay: day_tomorrow
		},
		dataType: "json",
		success: function(res) {
			// console.log(mounth_map + "---")
			// console.log(yy_text + "---")
			// console.log(res)
			// 遍历日期
			var defult_day = [];
			$(".worldSwitch .dateR ul li").remove();
			var length = res.have.length + 1;
			for (var i = 1; i < length; i++) {
				if (res.have[i - 1].isno == 1) {
					$(".worldSwitch .dateR ul").append("<li class='active'>" + i + "</li>");
					defult_day.push(i);
				} else {
					$(".worldSwitch .dateR ul").append("<li>" + i + "</li>");
				}
			}
			if (defult_day[0] == "" || defult_day[0] == undefined) {
				defult_day[0] = "";
			}
			//明天的时间
			var day3 = new Date();
			day3.setTime(day3.getTime() + 24 * 60 * 60 * 1000);
			// day3.setTime(day3.getTime() - 24 * 60 * 60 * 1000 * 4);
			var s3 = day3.getFullYear() + "-" + (day3.getMonth() + 1) + "-" + day3.getDate();
			var zz = day3.getDate();
			var current_m = (day3.getMonth() + 1);
			if (mounth_map == current_m) {
				$(".worldSwitch .dateR ul li").eq(zz - 1).css("color", "#ffc107");
			}
			if (zz < 10) {
				zz = "0" + zz;
			}

			// 选择日期赋值
			mounth_map_day = zz;
			$(".worldSwitch #global p").html("<strong>" + mounth_map_en + " " + zz + " , " +
				yy_text +
				"</strong> " +
				"Global Distribution of Prediction Omicron Cumulative New Cases");



			a1.setOption({
				timeline: {
					axisType: 'category',
					orient: 'vertical',
					autoPlay: true,
					inverse: true,
					playInterval: 5000,
					left: null,
					right: -105,
					top: 20,
					bottom: 20,
					width: 46,
					data: ['2016']
				},
				baseOption: {
					visualMap: {
						type: 'piecewise', //分段型。
						splitNumber: 6,
						inverse: false,
						itemWidth: 10,
						itemHeight: 10,
						splitNumber: 6,
						inverse: false,
						itemGap: 6,
						pieces: [
							{
								gte: 20000,
								color: "#800026"
							}, // (1500, Infinity]
							{
								min: 10000,
								max: 19999,
								color: "#b50026"
							}, // (900, 1500]
							{
								min: 5000,
								max: 9999,
								color: "#d9131e"
							}, // (900, 1500]
							{
								min: 2000,
								max: 4999,
								color: "#f23b24"
							}, // (900, 1500]
							{
								min: 1000,
								max: 1999,
								color: "#fc6e33"
							}, // (310, 1000]
							{
								min: 500,
								max: 999,
								color: "#fd9b42"
							}, // (200, 300]
							{
								min: 100,
								max: 499,
								color: "#fdbc57"
							}, // (200, 300]
							{
								min: 50,
								max: 99,
								color: "#fedb7c"
							},
							{
								min: 1,
								max: 49,
								color: "#ffeea2"
							},
							{
								lte: 0,
								label: '0',
								color: "#fff"
							} // (-Infinity, 5)
						],
						left: '3%',
						bottom: '3%',
						textStyle: {
							color: '#000'
						},
						//min: 0,
						//max: 60000,
						//text:['High','Low'],
						//realtime: true,
						//calculable: true,
						//color: ['red','orange','lightgreen']
					},
					series: [{
						type: 'map',
						map: 'world',
						zoom: 1.13,
						roam: false,
						itemStyle: {
							emphasis: {
								label: {
									show: false
								}
							}
						},
						nameMap: nameMap


					}]
				},

				options: [{
					// title: {
					//     text: '1.6 世界各国地均GDP',
					//     subtext: '国家基础地理信息中心',
					//     //sublink: 'http://esa.un.org/wpp/Excel-Data/population.htm',
					//     left: 'center',
					//     top: 'top'
					// },
					tooltip: {
						trigger: 'item',
						formatter: function(params) {
							var value = (params.value);
							//value = value.toFixed(5);toFixed(3)控制小数位数
							value = value;
							if (isNaN(value)) {
								value = "暂无病例数据"
							}
							//var abc=(params.abc);
							if (params.name == 0 || params.name ==
								undefined || params.name == "") {
								return value;
							} else {
								return params.name + '</br>' + value;
							}

						}
					},
					series: {
						data: res.country

					}
				}]
			});
		},
	})
})
// 全球年月日预测
$(".worldSwitch .dateR").on("click", ".active", function() {

	// $(".dateR  ul li").removeClass("active");
	// $(this).addClass("active");
	var mounth = $(".worldSwitch .dateL ul .active").index() + 1;
	// if (mounth_tomorrow < 10) {
	//  mounth_tomorrow = "0" + mounth_tomorrow;
	// } else {
	//  mounth_tomorrow = mounth_tomorrow;
	// }
	var day = $(this).text().trim()
	if (day < 10) {
		day = "0" + day;
	} else {
		day = day;
	}
	date = year_map + "-" + mounth_map + "-" + day;
	mounth_map_day = day;
	// console.log(date)
	// 获取当前月份
	var mounth_en = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"]
	var myDate = new Date();
	var month_ch = myDate.getMonth() + 1;
	$(".worldSwitch #global p").html("<strong>" + mounth_map_en + " " + mounth_map_day + " , " + year_map +
		"</strong> " +
		"Global Distribution of Prediction Omicron Cumulative New Cases");
	//明天的时间
	var day3 = new Date();
	day3.setTime(day3.getTime() + 24 * 60 * 60 * 1000);
	// day3.setTime(day3.getTime() - 24 * 60 * 60 * 1000 * 4);
	var s3 = day3.getFullYear() + "-" + (day3.getMonth() + 1) + "-" + day3.getDate();
	var zz = day3.getDate();
	$(".worldSwitch .dateR ul li").css("color", "#fff")
	$(this).css("color", "#ffeb3b")
	// $(".dateR ul li").eq(zz - 1).css("color", "#ffc107")


	$.ajax({
		type: "post",
		async: false,
		url: pub_url + "/predictData/monkeypoxEchartsData/globalAllData",
		data: {
			data: date
			// data: "2020-03-13"
		},
		dataType: "json",
		success: function(res) {
			// console.log(res)
			// 遍历日期
			a1.setOption({
				timeline: {
					axisType: 'category',
					orient: 'vertical',
					autoPlay: true,
					inverse: true,
					playInterval: 5000,
					left: null,
					right: -105,
					top: 20,
					bottom: 20,
					width: 46,
					data: ['2016']
				},
				baseOption: {
					visualMap: {
						type: 'piecewise', //分段型。
						splitNumber: 6,
						inverse: false,
						itemWidth: 10,
						itemHeight: 10,
						splitNumber: 6,
						inverse: false,
						itemGap: 6,
						pieces: [
							{
								gte: 20000,
								color: "#800026"
							}, // (1500, Infinity]
							{
								min: 10000,
								max: 19999,
								color: "#b50026"
							}, // (900, 1500]
							{
								min: 5000,
								max: 9999,
								color: "#d9131e"
							}, // (900, 1500]
							{
								min: 2000,
								max: 4999,
								color: "#f23b24"
							}, // (900, 1500]
							{
								min: 1000,
								max: 1999,
								color: "#fc6e33"
							}, // (310, 1000]
							{
								min: 500,
								max: 999,
								color: "#fd9b42"
							}, // (200, 300]
							{
								min: 100,
								max: 499,
								color: "#fdbc57"
							}, // (200, 300]
							{
								min: 50,
								max: 99,
								color: "#fedb7c"
							},
							{
								min: 1,
								max: 49,
								color: "#ffeea2"
							},
							{
								lte: 0,
								label: '0',
								color: "#fff"
							} // (-Infinity, 5)
						],
						left: '3%',
						bottom: '3%',
						textStyle: {
							color: '#000'
						},
						//min: 0,
						//max: 60000,
						//text:['High','Low'],
						//realtime: true,
						//calculable: true,
						//color: ['red','orange','lightgreen']
					},
					series: [{
						type: 'map',
						map: 'world',
						zoom: 1.13,
						roam: false,
						itemStyle: {
							emphasis: {
								label: {
									show: false
								}
							}
						},
						nameMap: nameMap


					}]
				},

				options: [{
					// title: {
					//     text: '1.6 世界各国地均GDP',
					//     subtext: '国家基础地理信息中心',
					//     //sublink: 'http://esa.un.org/wpp/Excel-Data/population.htm',
					//     left: 'center',
					//     top: 'top'
					// },
					tooltip: {
						trigger: 'item',
						formatter: function(params) {
							var value = (params.value);
							//value = value.toFixed(5);toFixed(3)控制小数位数
							value = value;
							if (isNaN(value)) {
								value = "暂无病例数据"
							}
							//var abc=(params.abc);
							if (params.name == 0 || params.name ==
								undefined || params.name == "") {
								return value;
							} else {
								return params.name + '</br>' + value;
							}

						}
					},
					series: {
						data: res

					}
				}]
			});
		},
	})
})
// 左侧曲线时间处理
$("#mount .mounthBox .mounth-cont ul").on("click", ".allow", function() {
	var index = 1;
	var this_text = $(this).text().trim();
	var this_mounth = this_text.substring(0, this_text.length - 4).trim(); //选中的月份
	var this_year = this_text.substring(this_text.length - 4, this_text.length); //选中的年份
	qxl_year = this_year; // 修改默认年份
	var mounth_en = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec"]
	var li_length = $("#mount .mounthBox .mounth-cont ul li").length;
	if (this_mounth == "Jan") {
		mounth_line = "01";
	} else if (this_mounth == "Feb") {
		mounth_line = "02";
	} else if (this_mounth == "Mar") {
		mounth_line = "03";
	} else if (this_mounth == "Apr") {
		mounth_line = "04";
	} else if (this_mounth == "May") {
		mounth_line = "05";
	} else if (this_mounth == "Jun") {
		mounth_line = "06";
	} else if (this_mounth == "Jul") {
		mounth_line = "07";
	} else if (this_mounth == "Aug") {
		mounth_line = "08";
	} else if (this_mounth == "Sept") {
		mounth_line = "09";
	} else if (this_mounth == "Oct") {
		mounth_line = "10";
	} else if (this_mounth == "Nov") {
		mounth_line = "11";
	} else if (this_mounth == "Dec") {
		mounth_line = "12";
	}

	$("#mount .mounthBox>p>strong").text(mounth_en[mounth_line - 1] + " " + qxl_year)
	// a2
	$.ajax({
		type: "post",
		async: false,
		url: pub_url + "/predictData/monkeypoxEchartsData/monthData",
		data: {
			countiy: countryL,
			month: mounth_line,
			timeYear: qxl_year
		},
		dataType: "json",
		success: function(res) {
			var date_day = [] //日期
			var value_forecast = [] //预测数值
			for (var i = 0; i < res.length; i++) {
				if (res[i].date < 10) {
					str = res[i].date.replace("0", "");
					date_day.push(str);
				} else {
					date_day.push(res[i].date);
				}

				value_forecast.push(res[i].forecast);
			}
			a2.setOption({
				backgroundColor: "transparent",
				tooltip: {
					trigger: 'axis',
					formatter: function(params) {
						if (params.length == 1 && params[0].seriesName ==
							"case") {
							var str = qxl_year + "-" + mounth_line + "-" + params[0]
								.name + "</br>" + countryL + "</br>" +
								"case：" +
								params[0].value;
							return str;
						}
					}
				},
				legend: {
					icon: "circle",
					itemGap: 10,
					itemWidth: 10, // 设置宽度
					itemHeight: 10, // 设置高度
					itemGap: 20, // 设置间距
					color: ["#FF6666"],
					data: ['case'],
					right: 80,
					textStyle: {
						color: "#0a2f60"
					}

				},
				grid: {
					show: false,
					// top: 'middle',
					left: '3%',
					right: '14%',
					bottom: '3%',
					top: "20%",
					color: '#fff',
					containLabel: true,
				},
				xAxis: {
					name: 'Day',
					type: 'category',
					boundaryGap: false,
					data: date_day,
					axisLine: {
						lineStyle: {
							color: "#fff"
						}
					},

					axisLabel: {
						show: true,
						textStyle: {
							color: "#fff", //X轴文字颜色
							fontSize: 12
						}
					},
				},
				yAxis: [{
					type: 'value',
					name: 'Number',
					minInterval: 1,
					splitLine: {
						show: false,
						lineStyle: {
							// type: 'dashed',
							color: '#fff'
						}
					},
					axisLine: {
						show: true,
						lineStyle: {
							color: "#fff"
						},
					},


					axisLabel: {
						show: true,
						textStyle: {
							color: "#fff", //X轴文字颜色
							fontSize: 12
						}
					},
					nameTextStyle: {
						color: "#fff"
					},
					splitArea: {
						show: false
					},

				}],
				series: [{
					name: 'case',
					type: 'line',
					data: value_forecast,
					color: "#FF6666",
					lineStyle: {
						normal: {
							width: 3,
							color: '#FF6666',
						}
					},
					itemStyle: {
						show: false,
						normal: {
							color: '#FF6666',
							borderWidth: 0,
							/*shadowColor: 'rgba(72,216,191, 0.3)',
							 shadowBlur: 100,*/
							borderColor: "#FF6666"
						}
					},
					smooth: true
				}]
			});
		},
	})
})
// 左侧曲线国家处理
$("#contryL .mounthBox .mounth-cont ul").on("click", "li", function() {
	var count_text = $(this).text().trim();
	countryL = count_text
	$("#contryL .mounthBox>p>strong").text(count_text)
	// a2
	$.ajax({
		type: "post",
		async: false,
		url: pub_url + "/predictData/monkeypoxEchartsData/monthData",
		data: {
			countiy: countryL,
			month: mounth_line,
			timeYear: qxl_year
		},
		dataType: "json",
		success: function(res) {
			var date_day = [] //日期
			var value_forecast = [] //预测数值
			for (var i = 0; i < res.length; i++) {
				if (res[i].date < 10) {
					str = res[i].date.replace("0", "");
					date_day.push(str);
				} else {
					date_day.push(res[i].date);
				}

				value_forecast.push(res[i].forecast);
			}
			a2.setOption({
				backgroundColor: "transparent",
				tooltip: {
					trigger: 'axis',
					formatter: function(params) {
						if (params.length == 1 && params[0].seriesName ==
							"case") {
							var str = qxl_year + "-" + mounth_line + "-" + params[0]
								.name + "</br>" + count_text + "</br>" +
								"case：" +
								params[0].value;
							return str;
						}
					}
				},
				legend: {
					icon: "circle",
					itemGap: 10,
					itemWidth: 10, // 设置宽度
					itemHeight: 10, // 设置高度
					itemGap: 20, // 设置间距
					color: ["#FF6666"],
					data: ['case'],
					right: 80,
					textStyle: {
						color: "#0a2f60"
					}

				},
				grid: {
					show: false,
					// top: 'middle',
					left: '3%',
					right: '14%',
					bottom: '3%',
					top: "20%",
					color: '#fff',
					containLabel: true,
				},
				xAxis: {
					name: 'Day',
					type: 'category',
					boundaryGap: false,
					data: date_day,
					axisLine: {
						lineStyle: {
							color: "#fff"
						}
					},

					axisLabel: {
						show: true,
						textStyle: {
							color: "#fff", //X轴文字颜色
							fontSize: 12
						}
					},
				},
				yAxis: [{
					type: 'value',
					name: 'Number',
					minInterval: 1,
					splitLine: {
						show: false,
						lineStyle: {
							// type: 'dashed',
							color: '#fff'
						}
					},
					axisLine: {
						show: true,
						lineStyle: {
							color: "#fff"
						},
					},


					axisLabel: {
						show: true,
						textStyle: {
							color: "#fff", //X轴文字颜色
							fontSize: 12
						}
					},
					nameTextStyle: {
						color: "#fff"
					},
					splitArea: {
						show: false
					},

				}],
				series: [{
					name: 'case',
					type: 'line',
					data: value_forecast,
					color: "#FF6666",
					lineStyle: {
						normal: {
							width: 3,
							color: '#FF6666',
						}
					},
					itemStyle: {
						show: false,
						normal: {
							color: '#FF6666',
							borderWidth: 0,
							/*: 'rgba(72,216,191, 0.3)',
							 shashadowColordowBlur: 100,*/
							borderColor: "#FF6666"
						}
					},
					smooth: true
				}]
			});
		},
	})
})
// 右侧曲线国家处理
$("#contry .mounthBox .mounth-cont ul").on("click", "li", function() {
	var count_text = $(this).text().trim();
	qx_country = count_text
	$("#contry .mounthBox>p>strong").text(count_text)
	// a3
	$.ajax({
		type: "post",
		async: false,
		url: pub_url + "/predictData/monkeypoxEchartsData/seasonData",
		data: {
			countiy: qx_country // 默认国家
		},
		dataType: "json",
		success: function(res) {
			$("#contry .mounthBox p strong").text(qx_country)
			if (res.length > 6) {
				// have_length = 100 - (6 / res.length * 100);
				have_length = (100 / res.length) * (res.length - 5)
			} else {
				have_length = 0;
			}

			var date_x = [] //x轴
			var date_y = [] //y轴
			for (var i = 0; i < res.length; i++) {
				date_x.push(res[i].date);
				date_y.push(res[i].forecast);
			}
			// chart
			a3.setOption({
				backgroundColor: "rgba(0,0,0,0)",
				"tooltip": {
					"trigger": "axis",
					"axisPointer": {
						"type": "line",
						textStyle: {
							color: "#fff"
						}
					},
					formatter: function(p) {
						var qx_tip = p[0];
						return (qx_tip.name + "</br>" + qx_country + "</br>" +
							'case：' + qx_tip.value);
					}
				},
				"grid": {
					"borderWidth": 0,
					"top": '15%',
					"left": '22%',
					"right": '18%',
					"bottom": 50,
					textStyle: {
						color: "#fff"
					}
				},



				"calculable": true,
				"xAxis": [{
					name: 'Month',
					"type": "category",
					"axisLine": {
						lineStyle: {
							color: '#fff'
						}
					},
					"splitLine": {
						"show": false
					},
					"axisTick": {
						"show": true
					},
					"splitArea": {
						"show": false
					},
					"axisLabel": {
						"interval": 1,
						fontSize: 12
					},
					"data": date_x,
				}],
				"yAxis": [{
					name: 'Number',
					"type": "value",
					"splitLine": {
						"show": false
					},

					"axisLine": {
						lineStyle: {
							color: '#fff'
						}
					},
					"axisTick": {
						"show": true
					},
					"axisLabel": {
						"interval": 0,

					},
					"splitArea": {
						"show": false
					},

				}],
				"dataZoom": [{
					"show": true,
					zoomLock: true,
					"height": 15,
					"width": '60%',
					"left": '20%',
					"filterMode": 'empty',
					"xAxisIndex": [
						0
					],
					bottom: 10,
					"start": have_length,
					"end": 100,
					handleIcon: 'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
					handleSize: '110%',
					backgroundColor: 'transparent',
					handleStyle: {
						color: "#d3dee5",

					},
					textStyle: {
						color: "#fff"
					},
					borderColor: "#fff"


				}, {
					"type": "slider",
					"show": false,
					"height": 15,
					"start": 1,
					"end": 35,
					backgroundColor: "#000"
				}],
				"series": [{
						"name": "预测评估",
						"type": "bar",
						"stack": "总量",

						"barMaxWidth": 15,
						"barGap": "10%",
						"itemStyle": {
							"normal": {
								"color": "#ff9080",
								"label": {
									"show": false,
									"textStyle": {
										"color": "#fff"
									},
									"position": "inside",
									// formatter: function(p) {
									//  console.log(p)
									//  return p.value > 0 ? (p.value) : '';
									// }
								}
							}
						},
						"data": date_y,
					},

					{
						"name": "预测评估",
						"type": "line",
						symbolSize: 5,
						smooth: true,
						symbol: 'circle',
						lineStyle: {
							color: '#fce630'
						},
						"itemStyle": {
							"normal": {
								"color": "#fff",
								"barBorderRadius": 0,
								"label": {
									"show": false,
									"position": "top",
									// formatter: function(p) {
									//  return p.value > 0 ? (p.value) : '';
									// }
								}
							}
						},
						"data": date_y
					},
				]
			});
		},
	})
})
// 点击左侧图标查询国家
$(".col_all .lessR .country ul").on("click", "li", function() {
	var str = $(this).find("span").text().trim();
	var c_name = str.lastIndexOf("/");
	str = str.substring(c_name + 1, str.length);
	countryL = str;
	$("#contryL .mounthBox p strong").text(countryL);
	$.ajax({
		type: "post",
		async: false,
		url: pub_url + "/predictData/monkeypoxEchartsData/monthData",
		data: {
			countiy: countryL,
			month: mounth_line,
			timeYear: qxl_year
		},
		dataType: "json",
		success: function(res) {
			var date_day = [] //日期
			var value_forecast = [] //预测数值
			for (var i = 0; i < res.length; i++) {
				if (res[i].date < 10) {
					str = res[i].date.replace("0", "");
					date_day.push(str);
				} else {
					date_day.push(res[i].date);
				}

				value_forecast.push(res[i].forecast);
			}
			a2.setOption({
				backgroundColor: "transparent",
				tooltip: {
					trigger: 'axis',
					formatter: function(params) {
						if (params.length == 1 && params[0].seriesName ==
							"case") {
							var str = qxl_year + "-" + mounth_line + "-" + params[0]
								.name + "</br>" + countryL + "</br>" +
								"case：" +
								params[0].value;
							return str;
						}
					}
				},
				legend: {
					icon: "circle",
					itemGap: 10,
					itemWidth: 10, // 设置宽度
					itemHeight: 10, // 设置高度
					itemGap: 20, // 设置间距
					color: ["#FF6666"],
					data: ['case'],
					right: 80,
					textStyle: {
						color: "#0a2f60"
					}

				},
				grid: {
					show: false,
					// top: 'middle',
					left: '3%',
					right: '14%',
					bottom: '3%',
					top: "20%",
					color: '#fff',
					containLabel: true,
				},
				xAxis: {
					type: 'category',
					// name: 'Number',
					boundaryGap: false,
					data: date_day,
					axisLine: {
						lineStyle: {
							color: "#fff"
						}
					},

					axisLabel: {
						show: true,
						textStyle: {
							color: "#fff", //X轴文字颜色
							fontSize: 12
						}
					},
				},
				yAxis: [{
					type: 'value',
					name: 'Number',
					minInterval: 1,
					splitLine: {
						show: false,
						lineStyle: {
							// type: 'dashed',
							color: '#fff'
						}
					},
					axisLine: {
						show: true,
						lineStyle: {
							color: "#fff"
						},
					},


					axisLabel: {
						show: true,
						textStyle: {
							color: "#fff", //X轴文字颜色
							fontSize: 12
						}
					},
					nameTextStyle: {
						color: "#fff"
					},
					splitArea: {
						show: false
					},

				}],
				series: [{
					name: 'case',
					type: 'line',
					data: value_forecast,
					color: "#FF6666",
					lineStyle: {
						normal: {
							width: 3,
							color: '#FF6666',
						}
					},
					itemStyle: {
						show: false,
						normal: {
							color: '#FF6666',
							borderWidth: 0,
							/*shadowColor: 'rgba(72,216,191, 0.3)',
							 shadowBlur: 100,*/
							borderColor: "#FF6666"
						}
					},
					smooth: true
				}]
			});
		},
	})
})
// 点击右侧图标查询国家
$(".col_less .lessR .country ul").on("click", "li", function() {
	var str = $(this).find("span").text().trim();
	var c_name = str.lastIndexOf("/");
	str = str.substring(c_name + 1, str.length);
	qx_country = str;

	$("#contry .mounthBox p strong").text(qx_country);
	// a3
	$.ajax({
		type: "post",
		async: false,
		url: pub_url + "/predictData/monkeypoxEchartsData/seasonData",
		data: {
			countiy: qx_country // 默认国家
		},
		dataType: "json",
		success: function(res) {
			$("#contry .mounthBox p strong").text(qx_country)
			if (res.length > 6) {
				// have_length = 100 - (6 / res.length * 100);
				have_length = (100 / res.length) * (res.length - 5)
			} else {
				have_length = 0;
			}

			var date_x = [] //x轴
			var date_y = [] //y轴
			for (var i = 0; i < res.length; i++) {
				date_x.push(res[i].date);
				date_y.push(res[i].forecast);
			}
			// chart
			a3.setOption({
				backgroundColor: "rgba(0,0,0,0)",
				"tooltip": {
					"trigger": "axis",
					"axisPointer": {
						"type": "line",
						textStyle: {
							color: "#fff"
						}
					},
					formatter: function(p) {
						var qx_tip = p[0];
						return (qx_tip.name + "</br>" + qx_country + "</br>" +
							'case：' + qx_tip.value);
					}
				},
				"grid": {
					"borderWidth": 0,
					"top": '15%',
					"left": '22%',
					"right": '18%',
					"bottom": 50,
					textStyle: {
						color: "#fff"
					}
				},



				"calculable": true,
				"xAxis": [{
					name: 'Month',
					"type": "category",
					"axisLine": {
						lineStyle: {
							color: '#fff'
						}
					},
					"splitLine": {
						"show": false
					},
					"axisTick": {
						"show": true
					},
					"splitArea": {
						"show": false
					},
					"axisLabel": {
						"interval": 1,
						fontSize: 12
					},
					"data": date_x,
				}],
				"yAxis": [{
					name: 'Number',
					"type": "value",
					"splitLine": {
						"show": false
					},

					"axisLine": {
						lineStyle: {
							color: '#fff'
						}
					},
					"axisTick": {
						"show": true
					},
					"axisLabel": {
						"interval": 0,

					},
					"splitArea": {
						"show": false
					},

				}],
				"dataZoom": [{
					"show": true,
					zoomLock: true,
					"height": 15,
					"width": '60%',
					"left": '20%',
					"filterMode": 'empty',
					"xAxisIndex": [
						0
					],
					bottom: 10,
					"start": have_length,
					"end": 100,
					handleIcon: 'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
					handleSize: '110%',
					backgroundColor: 'transparent',
					handleStyle: {
						color: "#d3dee5",

					},
					textStyle: {
						color: "#fff"
					},
					borderColor: "#fff"


				}, {
					"type": "slider",
					"show": false,
					"height": 15,
					"start": 1,
					"end": 35,
					backgroundColor: "#000"
				}],
				"series": [{
						"name": "预测评估",
						"type": "bar",
						"stack": "总量",

						"barMaxWidth": 15,
						"barGap": "10%",
						"itemStyle": {
							"normal": {
								"color": "#ff9080",
								"label": {
									"show": false,
									"textStyle": {
										"color": "#fff"
									},
									"position": "inside",
									// formatter: function(p) {
									//  console.log(p)
									//  return p.value > 0 ? (p.value) : '';
									// }
								}
							}
						},
						"data": date_y,
					},

					{
						"name": "预测评估",
						"type": "line",
						symbolSize: 5,
						smooth: true,
						symbol: 'circle',
						lineStyle: {
							color: '#fce630'
						},
						"itemStyle": {
							"normal": {
								"color": "#fff",
								"barBorderRadius": 0,
								"label": {
									"show": false,
									"position": "top",
									// formatter: function(p) {
									//  return p.value > 0 ? (p.value) : '';
									// }
								}
							}
						},
						"data": date_y
					},
				]
			});
		},
	})
})
// a1
var a1 = echarts.init(document.getElementById('a1'));
var a2 = echarts.init(document.getElementById('a2'));
var a3 = echarts.init(document.getElementById('a3'));


////////// 2004 年
var nameMap = {
	'Afghanistan': 'Afghanistan',
	'Albania': 'Albania',
	'Algeria': 'Algeria',
	'Andorra': 'Andorra',
	'Angola': 'Angola',
	'Antarctica': 'Antarctica',
	'Antigua and Barbuda': 'Antigua and Barbuda',
	'Argentina': 'Argentina',
	'Armenia': 'Armenia',
	'Australia': 'Australia',
	'Austria': 'Austria',
	'Azerbaijan': 'Azerbaijan',
	'The Bahamas': 'The Bahamas',
	'Bahrain': 'Bahrain',
	'Bangladesh': 'Bangladesh',
	'Barbados': 'Barbados',
	'Belarus': 'Belarus',
	'Belgium': 'Belgium',
	'Belize': 'Belize',
	'Benin': 'Benin',
	'Bermuda': 'Bermuda',
	'Bhutan': 'Bhutan',
	'Bolivia': 'Bolivia',
	'Bosnia and Herz.': 'Bosnia and Herzegovina',
	'Botswana': 'Botswana',
	'Brazil': 'Brazil',
	'Brunei': 'Brunei',
	'Bulgaria': 'Bulgaria',
	'Burkina Faso': 'Burkina Faso',
	'Burundi': 'Burundi',
	'Cambodia': 'Cambodia',
	'Cameroon': 'Cameroon',
	'Canada': 'Canada',
	'Cape Verde': 'Cape Verde',
	'Central African Rep.': 'Central African Republic',
	'Chad': 'Chad',
	'Chile': 'Chile',
	'China': 'China',
	'Colombia': 'Comoros',
	'Comoros': 'Comoros',
	// 'Dem. Rep. Congo': 'Congo (Brazzaville)',刚果布（刚果共和国）
	'Dem. Rep. Congo': 'Republic of Congo',
	'Costa Rica': 'Costa Rica',
	'Croatia': 'Croatia',
	'Cuba': 'Cuba',
	'Cyprus': 'Cyprus',
	// 'Czech Rep.': 'Czechia',
	'Czech Rep.': 'Czech Republic',
	'Denmark': 'Denmark',
	'Djibouti': 'Djibouti',
	'Dominica': 'Dominica',
	'Dominican Republic': 'Dominican Republic',
	'Ecuador': 'Ecuador',
	'Egypt': 'Egypt',
	'El Salvador': 'El Salvador',
	'Equatorial Guinea': 'Equatorial Guinea',
	'Eritrea': 'Eritrea',
	'Estonia': 'Estonia',
	'Ethiopia': 'Ethiopia',
	'Falkland Islands': 'Falkland Islands',
	'Faroe Islands': 'Faroe Islands',
	'Fiji': 'Fiji',
	'Finland': 'Finland',
	'France': 'France',
	'French Guiana': 'French Guiana',
	'French Southern and Antarctic Lands': 'French Southern and Antarctic Lands',
	'Gabon': 'Gabon',
	'Gaza Strip': 'Gaza Strip',
	'Georgia': 'Georgia',
	'Germany': 'Germany',
	'Ghana': 'Ghana',
	'Greece': 'Greece',
	'Greenland': 'Greenland',
	'Grenada': 'Grenada',
	'Guadeloupe': 'Guadeloupe',
	'Guatemala': 'Guatemala',
	'Guinea': 'Guinea',
	'Guinea Bissau': 'Guinea Bissau',
	'Guyana': 'Guyana',
	'Haiti': 'Haiti',
	'Honduras': 'Honduras',
	'Hong Kong': 'Hong Kong',
	'Hungary': 'Hungary',
	'Iceland': 'Iceland',
	'India': 'India',
	'Indonesia': 'Indonesia',
	'Iran': 'Iran',
	'Iraq': 'Iraq',
	'Iraq-Saudi Arabia Neutral Zone': 'Iraq-Saudi Arabia Neutral Zone',
	'Ireland': 'Ireland',
	'Isle of Man': 'Isle of Man',
	'Israel': 'Israel',
	'Italy': 'Italy',
	'Ivory Coast': "Cote d'Ivoire",
	'Jamaica': 'Jamaica',
	'Jan Mayen': 'Jan Mayen',
	'Japan': 'Japan',
	'Jordan': 'Jordan',
	'Kazakhstan': 'Kazakhstan',
	'Kenya': 'Kenya',
	'Kerguelen': 'Kerguelen',
	'Kiribati': 'Kiribati',
	'Dem. Rep. Korea': 'North Korea',
	'Korea': 'South Korea',
	'Kuwait': 'Kuwait',
	'Kyrgyzstan': 'Kyrgyzstan',
	'Lao PDR': 'Laos',
	'Latvia': 'Latvia',
	'Lebanon': 'Lebanon',
	'Lesotho': 'Lesotho',
	'Liberia': 'Liberia',
	'Libya': 'Libya',
	'Liechtenstein': 'Liechtenstein',
	'Lithuania': 'Lithuania',
	'Luxembourg': 'Luxembourg',
	'Macau': 'Macau',
	'Macedonia': 'Macedonia',
	'Madagascar': 'Madagascar',
	'Malawi': 'Malawi',
	'Malaysia': 'Malaysia',
	'Maldives': 'Maldives',
	'Mali': 'Mali',
	'Malta': 'Malta',
	'Martinique': 'Martinique',
	'Mauritania': 'Mauritania',
	'Mauritius': 'Mauritius',
	'Mexico': 'Mexico',
	'Moldova': 'Moldova',
	'Monaco': 'Monaco',
	'Mongolia': 'Mongolia',
	'Morocco': 'Morocco',
	'Mozambique': 'Mozambique',
	'Myanmar': 'Burma',
	'Namibia': 'Namibia',
	'Nepal': 'Nepal',
	'Netherlands': 'Netherlands',
	'New Caledonia': 'New Caledonia',
	'New Zealand': 'New Zealand',
	'Nicaragua': 'Nicaragua',
	'Niger': 'Niger',
	'Nigeria': 'Nigeria',
	'Northern Mariana Islands': 'Northern Mariana Islands',
	'Norway': 'Norway',
	'Oman': 'Oman',
	'Pakistan': 'Pakistan',
	'Panama': 'Panama',
	'Papua New Guinea': 'Papua New Guinea',
	'Paraguay': 'Paraguay',
	'Peru': 'Peru',
	'Philippines': 'Philippines',
	'Poland': 'Poland',
	'Portugal': 'Portugal',
	'Puerto Rico': 'Puerto Rico',
	'Qatar': 'Qatar',
	'Reunion': 'Reunion',
	'Romania': 'Romania',
	'Russia': 'Russia',
	'Rwanda': 'Rwanda',
	'San Marino': 'San Marino',
	'Sao Tome and Principe': 'Sao Tome and Principe',
	'Saudi Arabia': 'Saudi Arabia',
	'Senegal': 'Senegal',
	'Seychelles': 'Seychelles',
	'Sierra Leone': 'Sierra Leone',
	'Singapore': 'Singapore',
	'Slovakia': 'Slovakia',
	'Slovenia': 'Slovenia',
	'Solomon Islands': 'Solomon Islands',
	'Somalia': 'Somalia',
	'South Africa': 'South Africa',
	'Spain': 'Spain',
	'Sri Lanka': 'Sri Lanka',
	'St. Christopher-Nevis': 'St. Christopher-Nevis',
	'St. Lucia': 'St. Lucia',
	'St. Vincent and the Grenadines': 'St. Vincent and the Grenadines',
	'Sudan': 'Sudan',
	'Suriname': 'Suriname',
	'Svalbard': 'Svalbard',
	'Swaziland': 'Swaziland',
	'Sweden': 'Sweden',
	'Switzerland': 'Switzerland',
	'Syria': 'Syria',
	'Taiwan': 'Taiwan',
	'Tajikistan': 'Tajikistan',
	'United Republic of Tanzania': 'Tanzania',
	'Thailand': 'Thailand',
	'Togo': 'Togo',
	'Tonga': 'Tonga',
	'Trinidad and Tobago': 'Trinidad and Tobago',
	'Tunisia': 'Tunisia',
	'Turkey': 'Turkey',
	'Turkmenistan': 'Turkmenistan',
	'Turks and Caicos Islands': 'Turks and Caicos Islands',
	'Uganda': 'Uganda',
	'Ukraine': 'Ukraine',
	'United Arab Emirates': 'United Arab Emirates',
	'United Kingdom': 'United Kingdom',
	// 'United States': 'US',
	'United States': 'United States',
	'Uruguay': 'Uruguay',
	'Uzbekistan': 'Uzbekistan',
	'Vanuatu': 'Vanuatu',
	'Venezuela': 'Venezuela',
	'Vietnam': 'Vietnam',
	'W. Sahara': 'Western Sahara',
	'Western Samoa': 'Western Samoa',
	'Yemen': 'Yemen',
	'Yugoslavia': 'Yugoslavia',
	// 'Congo': 'Congo (Kinshasa)',刚果金（刚果民主共和国）
	'Congo': 'Democratic Republic Of The Congo',
	'Zambia': 'Zambia',
	'Zimbabwe': 'Zimbabwe',
	'S. Sudan': 'South Sudan',
	'Somaliland': 'Somaliland',
	'Montenegro': 'Montenegro',
	'Kosovo': 'Kosovo',
	'Republic of Serbia': 'Republic of Serbia',
};
// 查询明天的数据

$.ajax({
	type: "post",
	async: false,
	url: pub_url + "/predictData/monkeypoxEchartsData/globalData",
	data: {
		timeMonth: mounth_tomorrow,
		timeYear: year_map,
		timeDay: day_tomorrow
	},
	dataType: "json",
	success: function(res) {
		// console.log(res)
		// console.log(year_map)
		var defult_day = [];
		// 遍历日期
		$(".worldSwitch .dateR ul li").remove();
		var length = res.have.length + 1;
		for (var i = 1; i < length; i++) {
			if (res.have[i - 1].isno == 1) {
				$(".worldSwitch .dateR ul").append("<li class='active'>" + i + "</li>");
				defult_day.push(i);
			} else {
				$(".worldSwitch .dateR ul").append("<li>" + i + "</li>");
			}
		}
		if (defult_day[0] == "" || defult_day[0] == undefined) {
			defult_day[0] = "";
		}
		//明天的时间
		var day3 = new Date();
		day3.setTime(day3.getTime() + 24 * 60 * 60 * 1000);
		// day3.setTime(day3.getTime() - 24 * 60 * 60 * 1000 * 4);
		var s3 = day3.getFullYear() + "-" + (day3.getMonth() + 1) + "-" + day3.getDate();
		var zz = day3.getDate();
		if (zz < 10) {
			zz = "0" + zz
		}
		$(".worldSwitch .dateR ul li").eq(zz - 1).css("color", "#ffc107")
		// 当前显示时间赋值
		mounth_map_day = zz;
		// 获取当前月份
		var mounth_en = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov",
			"Dec"
		]
		var myDate = new Date();
		var month_ch = myDate.getMonth() + 1;
		mounth_map_en = mounth_en[mounth_tomorrow - 1];
		$(".worldSwitch #global p").html("<strong>" + mounth_map_en + " " + zz + " , " + yearNow +
			"</strong> " +
			"Global Distribution of Prediction Omicron Cumulative New Cases");

		/*
		 *全球日期查询-默认显示明天的数据
		 */
		a1.setOption({
			timeline: {
				axisType: 'category',
				orient: 'vertical',
				autoPlay: true,
				inverse: true,
				playInterval: 5000,
				left: null,
				right: -105,
				top: 20,
				bottom: 20,
				width: 46,
				data: ['2016']
			},
			baseOption: {
				visualMap: {
					type: 'piecewise', //分段型。
					splitNumber: 6,
					inverse: false,
					itemWidth: 10,
					itemHeight: 10,
					splitNumber: 6,
					inverse: false,
					itemGap: 6,
					pieces: [
						{
							gte: 20000,
							color: "#800026"
						}, // (1500, Infinity]
						{
							min: 10000,
							max: 19999,
							color: "#b50026"
						}, // (900, 1500]
						{
							min: 5000,
							max: 9999,
							color: "#d9131e"
						}, // (900, 1500]
						{
							min: 2000,
							max: 4999,
							color: "#f23b24"
						}, // (900, 1500]
						{
							min: 1000,
							max: 1999,
							color: "#fc6e33"
						}, // (310, 1000]
						{
							min: 500,
							max: 999,
							color: "#fd9b42"
						}, // (200, 300]
						{
							min: 100,
							max: 499,
							color: "#fdbc57"
						}, // (200, 300]
						{
							min: 50,
							max: 99,
							color: "#fedb7c"
						},
						{
							min: 1,
							max: 49,
							color: "#ffeea2"
						},
						{
							lte: 0,
							label: '0',
							color: "#fff"
						} // (-Infinity, 5)
					],
					left: '3%',
					bottom: '3%',
					textStyle: {
						color: '#000'
					},
					//min: 0,
					//max: 60000,
					//text:['High','Low'],
					//realtime: true,
					//calculable: true,
					//color: ['red','orange','lightgreen']
				},
				series: [{
					type: 'map',
					map: 'world',
					zoom: 1.13,
					roam: false,
					itemStyle: {
						emphasis: {
							label: {
								show: false
							}
						}
					},
					nameMap: nameMap


				}]
			},

			options: [{
				// title: {
				//     text: '1.6 世界各国地均GDP',
				//     subtext: '国家基础地理信息中心',
				//     //sublink: 'http://esa.un.org/wpp/Excel-Data/population.htm',
				//     left: 'center',
				//     top: 'top'
				// },
				tooltip: {
					trigger: 'item',
					formatter: function(params) {
						var value = (params.value);
						//value = value.toFixed(5);toFixed(3)控制小数位数
						value = value;
						if (isNaN(value)) {
							value = "暂无病例数据"
						} else {
							$(".worldSwitch #a1>div:eq(1)").css("opacity", "1")
						}
						if (params.name == 0 || params.name == undefined || params
							.name == "") {
							return value;
						} else {
							return params.name + '</br>' + value;
						}
						//var abc=(params.abc);


					}
				},
				series: {
					data: res.country

				}
			}]
		});
	},
})





// a2


// console.log(month_current)
// console.log(countryL)
// console.log(qxl_year)
// 左侧曲线
$.ajax({
	type: "post",
	async: false,
	url: pub_url + "/predictData/monkeypoxEchartsData/monthData",
	data: {
		month: month_current, //当前月份
		countiy: countryL, // 默认国家
		timeYear: qxl_year
	},
	dataType: "json",
	success: function(res) {
		// console.log(res)
		var date_day = [] //x轴
		var value_forecast = [] //预测数值
		for (var i = 0; i < res.length; i++) {
			if (res[i].date < 10) {
				str = res[i].date.replace("0", "");
				date_day.push(str);
			} else {
				date_day.push(res[i].date);
			}

			value_forecast.push(res[i].forecast);
		}
		/*for (var i = 0; i < res.length; i++) {
			date_day.push(res[i].date);
			value_forecast.push(res[i].forecast);
		}*/
		// 替换下拉默认的值
		var mounth_en = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov",
			"Dec"
		]
		mounth_map_en = mounth_en[mounth_line - 1];
		//明天的时间
		var day3 = new Date();
		day3.setTime(day3.getTime());
		var s3 = day3.getFullYear();
		// console.log(s3)

		$("#mount p strong").text(mounth_map_en + " " + yearNow); //给月份赋值
		$("#contryL p strong").text(countryL)
		// chart
		a2.setOption({
			backgroundColor: "transparent",
			tooltip: {
				trigger: 'axis',
				formatter: function(params) {
					var str = s3 + "-" + mounth_line + "-" + params[0].name + "</br>" +
						countryL + "</br>case：" +
						params[
							0].value;
					return str;
				}
			},
			legend: {
				icon: "circle",
				itemGap: 10,
				itemWidth: 10, // 设置宽度
				itemHeight: 10, // 设置高度
				itemGap: 20, // 设置间距
				color: ["#FF6666"],
				// data: ['prediction'],
				data: ['case'],
				right: 80,
				textStyle: {
					color: "#0a2f60"
				}

			},
			grid: {
				show: false,
				// top: 'middle',
				left: '3%',
				right: '14%',
				bottom: '3%',
				top: "20%",
				color: '#fff',
				containLabel: true,
			},
			xAxis: {
				name: 'Day',
				type: 'category',
				boundaryGap: false,
				data: date_day,
				axisLine: {
					lineStyle: {
						color: "#fff"
					}
				},

				axisLabel: {
					show: true,
					textStyle: {
						color: "#fff", //X轴文字颜色
						fontSize: 12
					}
				},
			},
			yAxis: [{
				type: 'value',
				name: 'Number',
				minInterval: 1,
				splitLine: {
					show: false,
					lineStyle: {
						// type: 'dashed',
						color: '#fff'
					}
				},
				axisLine: {
					show: true,
					lineStyle: {
						color: "#fff"
					},
				},


				axisLabel: {
					show: true,
					textStyle: {
						color: "#fff", //X轴文字颜色
						fontSize: 12
					}
				},
				nameTextStyle: {
					color: "#fff"
				},
				splitArea: {
					show: false
				},

			}],
			series: [{
				// name: 'prediction',
				name: 'case',
				type: 'line',
				data: value_forecast,
				color: "#FF6666",
				lineStyle: {
					normal: {
						width: 3,
						color: '#FF6666',
					}
				},
				itemStyle: {
					show: false,
					normal: {
						color: '#FF6666',
						borderWidth: 0,
						/*shadowColor: 'rgba(72,216,191, 0.3)',
						 shadowBlur: 100,*/
						borderColor: "#FF6666"
					}
				},
				smooth: true
			}]
		});
	},
})
// a3右侧曲线
$.ajax({
	type: "post",
	async: false,
	url: pub_url + "/predictData/monkeypoxEchartsData/seasonData",
	data: {
		countiy: qx_country // 默认国家
	},
	dataType: "json",
	success: function(res) {
		// console.log(res)
		$("#contry .mounthBox p strong").text(qx_country)
		if (res.length > 6) {
			// have_length = 100 - (6 / res.length * 100);
			have_length = (100 / res.length) * (res.length - 5)
		} else {
			have_length = 0;
		}
		var date_x = [] //x轴
		var date_y = [] //y轴
		for (var i = 0; i < res.length; i++) {
			date_x.push(res[i].date);
			date_y.push(res[i].forecast);
		}
		// chart
		a3.setOption({
			backgroundColor: "rgba(0,0,0,0)",
			"tooltip": {
				"trigger": "axis",
				"axisPointer": {
					"type": "line",
					textStyle: {
						color: "#fff"
					}
				},
				formatter: function(p) {
					var qx_tip = p[0];
					return (qx_tip.name + "</br>" + qx_country + "</br>" + 'case：' +
						qx_tip.value);
				}
			},
			"grid": {
				"borderWidth": 0,
				"top": '15%',
				"left": '22%',
				"right": '18%',
				"bottom": 50,
				textStyle: {
					color: "#fff"
				}
			},



			"calculable": true,
			"xAxis": [{
				name: 'Month',
				"type": "category",
				"axisLine": {
					lineStyle: {
						color: '#fff'
					}
				},
				"splitLine": {
					"show": false
				},
				"axisTick": {
					"show": true
				},
				"splitArea": {
					"show": false
				},
				"axisLabel": {
					"interval": 1,
					fontSize: 12
				},
				"data": date_x,
			}],
			"yAxis": [{
				name: 'Number',
				"type": "value",
				"splitLine": {
					"show": false
				},

				"axisLine": {
					lineStyle: {
						color: '#fff'
					}
				},
				"axisTick": {
					"show": true
				},
				"axisLabel": {
					"interval": 0,

				},
				"splitArea": {
					"show": false
				},

			}],
			"dataZoom": [{
				"show": true,
				zoomLock: true,
				"height": 15,
				"width": '60%',
				"left": '20%',
				"filterMode": 'empty',
				"xAxisIndex": [
					0
				],
				bottom: 10,
				"start": have_length,
				"end": 100,
				handleIcon: 'path://M306.1,413c0,2.2-1.8,4-4,4h-59.8c-2.2,0-4-1.8-4-4V200.8c0-2.2,1.8-4,4-4h59.8c2.2,0,4,1.8,4,4V413z',
				handleSize: '110%',
				backgroundColor: 'transparent',
				handleStyle: {
					color: "#d3dee5",

				},
				textStyle: {
					color: "#fff"
				},
				borderColor: "#fff"


			}, {
				"type": "slider",
				"show": false,
				"height": 15,
				"start": 1,
				"end": 35,
				backgroundColor: "#000"
			}],
			"series": [{
					"name": "预测评估",
					"type": "bar",
					"stack": "总量",

					"barMaxWidth": 15,
					"barGap": "10%",
					"itemStyle": {
						"normal": {
							"color": "#ff9080",
							"label": {
								"show": false,
								"textStyle": {
									"color": "#fff"
								},
								"position": "inside",
								// formatter: function(p) {
								//  console.log(p)
								//  return p.value > 0 ? (p.value + 'sssssssssss' ) : '';
								// }
							}
						}
					},
					"data": date_y,
				},

				{
					"name": "预测评估",
					"type": "line",
					symbolSize: 5,
					smooth: true,
					symbol: 'circle',
					lineStyle: {
						color: '#fce630'
					},
					"itemStyle": {
						"normal": {
							"color": "#fff",
							"barBorderRadius": 0,
							"label": {
								"show": false,
								"position": "top",
								// formatter: function(p) {
								//  return 0;
								// }
							}
						}
					},
					"data": date_y
				},
			]
		});
	},
})

// 添加月份
$.ajax({
	type: "post",
	async: false,
	url: "http://202.201.0.41/system/forecast/month.jsp",
	data: {},
	dataType: "json",
	success: function(res) {
		var result = [
			{
				"isNull": 1,
				"month": "01",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "02",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "03",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "04",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "05",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "06",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "07",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "08",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "09",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "10",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "11",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "12",
				"year": "2022"
			},
			{
				"isNull": 1,
				"month": "01",
				"year": "2023"
			},
			{
				"isNull": 1,
				"month": "02",
				"year": "2023"
			},
			{
				"isNull": 1,
				"month": "03",
				"year": "2023"
			},
			{
				"isNull": 1,
				"month": "04",
				"year": "2023"
			},
			{
				"isNull": 1,
				"month": "05",
				"year": "2023"
			},
			{
				"isNull": 1,
				"month": "06",
				"year": "2023"
			},
			{
				"isNull": 1,
				"month": "07",
				"year": "2023"
			},
			{
				"isNull": 1,
				"month": "08",
				"year": "2023"
			},
		]
		var mounth_en = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov",
			"Dec"
		]
		//  全球月份添加
		var global_mounth = ["一月新增预测", "二月新增预测", "三月新增预测", "四月新增预测", "五月新增预测", "六月新增预测", "七月新增预测",
			"八月新增预测", "九月新增预测",
			"十月新增预测", "十一月新增预测", "十二月新增预测"
		]

		var isNull; //0无数据，1有数据
		var index_m = 0;
		// 曲线部分清空原数据
		$("#mount ul li").remove();
		//全球月份清除原数据
		$(".worldSwitch .dateBox .dateL>ul>li").remove();
		for (var i = 0; i < result.length; i++) {

			// 判断是否有值
			if (result[i].isNull == 0) {
				isNull = "disabled";
			} else {
				isNull = "allow";
			}
			// 判断是否为选择状态

			if (i > 11) {

				$("#mount ul").append('<li class="' + isNull + '">' + mounth_en[result[i % 11 - 1].month -
						1] + " " + result[i].year +
					'</li>'); //曲线左侧时间
				$(".worldSwitch .dateBox .dateL>ul").append('<li class="' + isNull + '">' + '<p>' +
					global_mounth[result[
							i % 11 - 1].month -
						1] +
					'</p>' + '<span>' +
					mounth_en[result[i % 11 - 1].month - 1] + " " + result[i].year + '</span>' + '</li>');
			} else {
				$("#mount ul").append('<li class="' + isNull + '">' + mounth_en[result[i].month - 1] + " " +
					result[i].year +
					'</li>');
				// 全球月份添加禁用类名
				$(".worldSwitch .dateBox .dateL>ul").append('<li class="' + isNull + '">' + '<p>' +
					global_mounth[result[
						i].month - 1] +
					'</p>' + '<span>' +
					mounth_en[result[i].month - 1] + " " + result[i].year + '</span>' + '</li>');
			}



		}
		// 地图月份选择赋值
		//明天的时间
		var day4 = new Date();
		day4.setTime(day4.getTime() + 24 * 60 * 60 * 1000);
		// day4.setTime(day4.getTime() - 24 * 60 * 60 * 1000 * 4);
		var s4 = day4.getFullYear();
		// console.log(s4)
		$(".worldSwitch .dateBox .dateL>p").text(global_mounth[mounth_tomorrow - 1])
		$(".worldSwitch .dateBox .dateL>span").text(mounth_en[mounth_tomorrow - 1] + " " + s4)
		// 折线右侧月份
		$(".worldSwitch .dateBox .dateL>ul li").eq(mounth_tomorrow - 1).addClass("active");
		$("#contryL ul li").eq(0).removeClass("disabled");

	}
});

var swiper = new Swiper('.swiper-container', {
	effect: 'flip',
	direction: 'vertical',
	loop: true,
	grabCursor: true,
	autoplay: {
		delay: 3000,
		stopOnLastSlide: false,
		disableOnInteraction: true,
	},
	navigation: {
		nextEl: '.swiper-button-next',
		prevEl: '.swiper-button-prev',
	},
});
